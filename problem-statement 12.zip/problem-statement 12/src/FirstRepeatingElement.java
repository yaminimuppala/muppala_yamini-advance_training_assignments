import java.util.*;
	 
	public class FirstRepeatingElement {
	
	    static void printFirstRepeating(int arr[])
	    {
	       
	        int min = -1;
	 

	        HashSet<Integer> set = new HashSet<>();
	 
	       
	        for (int i=arr.length-1; i>=0; i--)
	        {
	            
	            if (set.contains(arr[i]))
	                min = i;
	 
	            else   
	                set.add(arr[i]);
	        }
	 
	       
	        if (min != -1)
	          System.out.println("The first repeating element is " + arr[min]);
	        else
	          System.out.println("There are no repeating elements");
	    }
	 
	    
	    public static void main (String[] args) throws java.lang.Exception
	    {
	        int arr[] = {8,5,4,2,1,5,4,7 };
	        printFirstRepeating(arr);
	        
	        int arr1[] = {9,8,7,2,4,5,2,1,6};
	        printFirstRepeating(arr1);
	        
	        
	    }
	}



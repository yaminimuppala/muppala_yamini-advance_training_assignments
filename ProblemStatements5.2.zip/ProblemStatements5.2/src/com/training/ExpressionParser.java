package com.training;

public class ExpressionParser {
	public static void main(String[] args) {
		
	
	String txt= (" 26  +  55  -  (  443  /  13  ) ");
	String[] w=txt.split("\\s");
	
	for(String w1:w){  
		System.out.println(w1); 
		//System.out.println(" ");
	}
}

}
package com.yamini.training;

public abstract class Instrument {
	public abstract void play();
}
